package com.codeforany.online_groceries

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
